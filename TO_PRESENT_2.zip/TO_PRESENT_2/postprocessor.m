% PLot the stress contour
% Current Stresses

festrs11